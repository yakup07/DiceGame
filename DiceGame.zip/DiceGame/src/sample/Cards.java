package sample;

public enum Cards {
    blueCardX,
    orangeCard4,
    greenCardX,
    foxCard,
    yellowCardX,
    plusOneCard,
    reRollCard,
    purpleCard6,
    orangeCard5,
    orangeCard6,
}
