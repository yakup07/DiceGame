package sample;

public enum DiceCategories {
    yellow,
    white,
    purple,
    green,
    blue,
    orange
}
